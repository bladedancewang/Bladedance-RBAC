/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.controller;


import com.bladedance.annotation.Login;
import com.bladedance.common.utils.Result;
import com.bladedance.common.validator.ValidatorUtils;
import com.bladedance.dto.LoginDTO;
import com.bladedance.service.TokenService;
import com.bladedance.service.UserService;
import com.bladedance.annotation.Login;
import com.bladedance.common.utils.Result;
import com.bladedance.common.validator.ValidatorUtils;
import com.bladedance.dto.LoginDTO;
import com.bladedance.service.TokenService;
import com.bladedance.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Map;

/**
 * 登录接口
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
@RestController
@RequestMapping("/api" )
@Api(tags = "登录接口" )
public class ApiLoginController {
    @Autowired
    private UserService userService;
    @Autowired
    private TokenService tokenService;


    @PostMapping("login" )
    @ApiOperation("登录" )
    public Result<Map<String, Object>> login(@RequestBody LoginDTO dto) {
        //表单校验
        ValidatorUtils.validateEntity(dto);

        //用户登录
        Map<String, Object> map = userService.login(dto);

        return new Result().ok(map);
    }

    @Login
    @PostMapping("logout" )
    @ApiOperation("退出" )
    public Result logout(@ApiIgnore @RequestAttribute("userId" ) Long userId) {
        tokenService.expireToken(userId);
        return new Result();
    }

}