/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.service;

import com.bladedance.common.service.BaseService;
import com.bladedance.entity.TokenEntity;
import com.bladedance.common.service.BaseService;
import com.bladedance.entity.TokenEntity;

/**
 * 用户Token
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface TokenService extends BaseService<TokenEntity> {

    TokenEntity getByToken(String token);

    /**
     * 生成token
     * @param userId  用户ID
     * @return 返回token信息
     */
    TokenEntity createToken(Long userId);

    /**
     * 设置token过期
     * @param userId 用户ID
     */
    void expireToken(Long userId);

}
