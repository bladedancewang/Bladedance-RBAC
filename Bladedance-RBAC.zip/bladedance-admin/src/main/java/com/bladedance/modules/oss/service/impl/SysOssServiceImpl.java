/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.oss.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bladedance.modules.oss.dao.SysOssDao;
import com.bladedance.modules.oss.entity.SysOssEntity;
import com.bladedance.common.constant.Constant;
import com.bladedance.common.page.PageData;
import com.bladedance.common.service.impl.BaseServiceImpl;
import com.bladedance.modules.oss.dao.SysOssDao;
import com.bladedance.modules.oss.entity.SysOssEntity;
import com.bladedance.modules.oss.service.SysOssService;
import org.springframework.stereotype.Service;

import java.util.Map;


@Service
public class SysOssServiceImpl extends BaseServiceImpl<SysOssDao, SysOssEntity> implements SysOssService {

    @Override
    public PageData<SysOssEntity> page(Map<String, Object> params) {
        IPage<SysOssEntity> page = baseDao.selectPage(
                getPage(params, Constant.CREATE_DATE, false),
                new QueryWrapper<>()
        );
        return getPageData(page, SysOssEntity.class);
    }
}
