/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.message.service;

import com.bladedance.modules.message.dto.SysMailLogDTO;
import com.bladedance.modules.message.entity.SysMailLogEntity;
import com.bladedance.common.page.PageData;
import com.bladedance.common.service.BaseService;
import com.bladedance.modules.message.dto.SysMailLogDTO;
import com.bladedance.modules.message.entity.SysMailLogEntity;

import java.util.Map;

/**
 * 邮件发送记录
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface SysMailLogService extends BaseService<SysMailLogEntity> {

    PageData<SysMailLogDTO> page(Map<String, Object> params);

    /**
     * 保存邮件发送记录
     * @param templateId  模板ID
     * @param from        发送者
     * @param to          收件人
     * @param cc          抄送
     * @param subject     主题
     * @param content     邮件正文
     * @param status      状态
     */
    void save(Long templateId, String from, String[] to, String[] cc, String subject, String content, Integer status);
}

