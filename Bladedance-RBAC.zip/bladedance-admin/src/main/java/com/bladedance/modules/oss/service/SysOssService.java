/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.oss.service;

import com.bladedance.modules.oss.entity.SysOssEntity;
import com.bladedance.common.page.PageData;
import com.bladedance.common.service.BaseService;
import com.bladedance.modules.oss.entity.SysOssEntity;

import java.util.Map;

/**
 * 文件上传
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface SysOssService extends BaseService<SysOssEntity> {

    PageData<SysOssEntity> page(Map<String, Object> params);
}
