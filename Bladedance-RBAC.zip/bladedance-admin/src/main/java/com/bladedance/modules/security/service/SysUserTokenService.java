/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.security.service;

import com.bladedance.modules.security.entity.SysUserTokenEntity;
import com.bladedance.common.service.BaseService;
import com.bladedance.common.utils.Result;
import com.bladedance.modules.security.entity.SysUserTokenEntity;

/**
 * 用户Token
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface SysUserTokenService extends BaseService<SysUserTokenEntity> {

    /**
     * 生成token
     * @param userId  用户ID
     */
    Result createToken(Long userId);

    /**
     * 退出，修改token值
     * @param userId  用户ID
     */
    void logout(Long userId);

}