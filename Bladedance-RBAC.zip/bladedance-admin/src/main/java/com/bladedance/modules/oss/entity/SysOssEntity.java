/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.oss.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.bladedance.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 文件上传
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("sys_oss" )
public class SysOssEntity extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * URL地址
     */
    private String url;

}