package com.bladedance.modules.funcitonCode.lambda;
/*
    面向对象思想：
        做一件事情，找一个能解决这个事情的对象，调用对象的方法，完成事情
    函数式编程思想：
        只要能获取到结果，谁去做的，怎么做的都不重要，重视的是结构，不重视过程


 */


import lombok.var;

import javax.swing.*;


public class LambdaTest {

    public static void repeat(int n,Runnable action){
        for(int i=0;i<n;i++){
            action.run();
        }
    }
    public static void main(String[] args) {
//        new Timer(1000, e -> System.out.println(e));

//        new Timer(1000, System.out::println);

        System.out.println("延迟执行repeat方法");
        repeat(10,()->System.out.println("延迟执行repeat方法"));
    }
}
