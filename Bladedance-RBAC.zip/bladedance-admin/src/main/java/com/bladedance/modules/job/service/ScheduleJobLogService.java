/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.job.service;

import com.bladedance.modules.job.dto.ScheduleJobLogDTO;
import com.bladedance.modules.job.entity.ScheduleJobLogEntity;
import com.bladedance.common.page.PageData;
import com.bladedance.common.service.BaseService;
import com.bladedance.modules.job.dto.ScheduleJobLogDTO;
import com.bladedance.modules.job.entity.ScheduleJobLogEntity;

import java.util.Map;

/**
 * 定时任务日志
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface ScheduleJobLogService extends BaseService<ScheduleJobLogEntity> {

    PageData<ScheduleJobLogDTO> page(Map<String, Object> params);

    ScheduleJobLogDTO get(Long id);
}
