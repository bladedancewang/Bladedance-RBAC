/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.demo.dao;

import com.bladedance.common.dao.BaseDao;
import com.bladedance.modules.demo.entity.NewsEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 新闻
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
@Mapper
public interface NewsDao extends BaseDao<NewsEntity> {

    List<NewsEntity> getList(Map<String, Object> params);

}
