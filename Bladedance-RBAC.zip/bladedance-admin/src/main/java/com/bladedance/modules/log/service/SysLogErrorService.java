/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.log.service;


import com.bladedance.modules.log.dto.SysLogErrorDTO;
import com.bladedance.modules.log.entity.SysLogErrorEntity;
import com.bladedance.common.page.PageData;
import com.bladedance.common.service.BaseService;
import com.bladedance.modules.log.dto.SysLogErrorDTO;
import com.bladedance.modules.log.entity.SysLogErrorEntity;

import java.util.List;
import java.util.Map;

/**
 * 异常日志
 *
 * @author wangjiajian bladedance@vip.qq.coom
 * @since 1.0.0
 */
public interface SysLogErrorService extends BaseService<SysLogErrorEntity> {

    PageData<SysLogErrorDTO> page(Map<String, Object> params);

    List<SysLogErrorDTO> list(Map<String, Object> params);

    void save(SysLogErrorEntity entity);

}