package com.bladedance.modules.funcitonCode;

public class FunctionCodeTestImpl implements FunctionCodeTest {


    @Override
    public int testMethod(String s) {

        System.out.println("函数式接口的实现类的方法覆盖抽象方法===>" + s);
        System.out.println("lamda表达式实现函数式接口中抽象方法我可用干很多额外的事情" + s);
        return s.length();
    }


}
