package com.bladedance.modules.funcitonCode.lambda;

public class RunnableImplTest {
    public static void repeat(int n,Runnable action){
        for(int i=0;i<n;i++){
            action.run();
        }
    }


    public static void main(String[] args) {
        RunnableImplTest.repeat(10,()->System.out.println("延迟执行repeat方法"));
        System.out.println("repeat");

        new Thread(new RunnableImpl()).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println(Thread.currentThread().getName() + "create new thread by innerclass" );
            }
        }).start();


        new Thread(() -> {
            System.out.println(Thread.currentThread().getName() + "create new thread by lambda" );
        }).start();

        new Thread(() -> System.out.println(Thread.currentThread().getName() + "create new thread by lambda for simple" )).start();


        RunnableImplTest.repeat(10,()->System.out.println("延迟执行repeat方法"));

    }


}





