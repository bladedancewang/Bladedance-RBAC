/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.security.service;

import com.bladedance.modules.security.entity.SysUserTokenEntity;
import com.bladedance.modules.security.user.UserDetail;
import com.bladedance.modules.sys.entity.SysUserEntity;
import com.bladedance.modules.security.user.UserDetail;
import com.bladedance.modules.sys.entity.SysUserEntity;
import com.bladedance.modules.security.entity.SysUserTokenEntity;

import java.util.List;
import java.util.Set;

/**
 * shiro相关接口
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface ShiroService {
    /**
     * 获取用户权限列表
     */
    Set<String> getUserPermissions(UserDetail user);

    SysUserTokenEntity getByToken(String token);

    /**
     * 根据用户ID，查询用户
     * @param userId
     */
    SysUserEntity getUser(Long userId);

    /**
     * 获取用户对应的部门数据权限
     * @param userId  用户ID
     * @return 返回部门ID列表
     */
    List<Long> getDataScopeList(Long userId);
}
