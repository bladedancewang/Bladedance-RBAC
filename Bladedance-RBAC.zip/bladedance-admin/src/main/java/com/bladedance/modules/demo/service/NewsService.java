/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.demo.service;

import com.bladedance.modules.demo.dto.NewsDTO;
import com.bladedance.modules.demo.entity.NewsEntity;
import com.bladedance.common.page.PageData;
import com.bladedance.common.service.BaseService;
import com.bladedance.modules.demo.dto.NewsDTO;
import com.bladedance.modules.demo.entity.NewsEntity;

import java.util.Map;

/**
 * 新闻
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface NewsService extends BaseService<NewsEntity> {

    PageData<NewsDTO> page(Map<String, Object> params);

    NewsDTO get(Long id);

    void save(NewsDTO dto);

    void update(NewsDTO dto);
}

