/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.message.service;

import com.bladedance.modules.message.dto.SysMailTemplateDTO;
import com.bladedance.modules.message.entity.SysMailTemplateEntity;
import com.bladedance.common.service.CrudService;
import com.bladedance.modules.message.dto.SysMailTemplateDTO;
import com.bladedance.modules.message.entity.SysMailTemplateEntity;

/**
 * 邮件模板
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public interface SysMailTemplateService extends CrudService<SysMailTemplateEntity, SysMailTemplateDTO> {

    /**
     * 发送邮件
     * @param id           邮件模板ID
     * @param mailTo       收件人
     * @param mailCc       抄送
     * @param params       模板参数
     */
    boolean sendMail(Long id, String mailTo, String mailCc, String params) throws Exception;
}