/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.message.dao;

import com.bladedance.common.dao.BaseDao;
import com.bladedance.modules.message.entity.SysSmsEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 短信
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
@Mapper
public interface SysSmsDao extends BaseDao<SysSmsEntity> {

}
