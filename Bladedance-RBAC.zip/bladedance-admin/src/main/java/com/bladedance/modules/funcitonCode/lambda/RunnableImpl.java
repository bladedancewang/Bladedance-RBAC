package com.bladedance.modules.funcitonCode.lambda;

public class RunnableImpl implements Runnable {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + "create new thread " );
    }
}
