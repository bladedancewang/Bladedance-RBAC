package com.bladedance.modules.funcitonCode;

/*
    函数式接口的使用：一般可用作为方法的参数和返回值类型
 */
public class FunctionInterfaceTest {
    //定义一个方法，参数使用函数式接口的FunctionCodeTest
    public static void show(String s, FunctionCodeTest functionCodeTest) {
        System.out.println("参数字符串长度为：" + functionCodeTest.testMethod(s));

    }

    public static void repeat(int n,Runnable action){
        for(int i=0;i<n;i++){
            action.run();
        }
    }
    public static void main(String[] args) {
        String s = "带参数的函数式接口方法调用";
        //调用show，方法的参数是一个接口，所以可用传递接口的实现类对象
        show(s, new FunctionCodeTestImpl());

        show(s, new FunctionCodeTest() {
            @Override
            public int testMethod(String s) {
                System.out.println("匿名内部类方式实现接口参数中的抽象方法===>" + s);
                System.out.println("lamda表达式实现函数式接口中抽象方法我可用干很多额外的事情" + s);
                return s.length();
            }
        });
        //lamda表达式调用show方法，因为方法的参数是一个函数式接口，所以我们可用lamda表达式
        show(s, (lambdaStringPara) -> {
            System.out.println("lamda表达式实现函数式接口中抽象方法++++++lambda++++++===" + lambdaStringPara);
            System.out.println("lamda表达式实现函数式接口中抽象方法我可用干很多额外的事情" + lambdaStringPara);
            return s.length();
        });


        show(s, lambdaStringPara -> lambdaStringPara.length());

        System.out.println("=====================================================" );



    }
}
