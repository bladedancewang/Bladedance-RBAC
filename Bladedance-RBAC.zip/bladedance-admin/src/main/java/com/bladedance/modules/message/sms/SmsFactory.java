/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.modules.message.sms;

import com.bladedance.modules.sys.service.SysParamsService;
import com.bladedance.common.constant.Constant;
import com.bladedance.common.utils.SpringContextUtils;
import com.bladedance.modules.sys.service.SysParamsService;

/**
 * 短信Factory
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
public class SmsFactory {
    private static SysParamsService sysParamsService;

    static {
        SmsFactory.sysParamsService = SpringContextUtils.getBean(SysParamsService.class);
    }

    public static AbstractSmsService build() {
        //获取短信配置信息
        SmsConfig config = sysParamsService.getValueObject(Constant.SMS_CONFIG_KEY, SmsConfig.class);

        if (config.getPlatform() == Constant.SmsService.ALIYUN.getValue()) {
            return new AliyunSmsService(config);
        } else if (config.getPlatform() == Constant.SmsService.QCLOUD.getValue()) {
            return new QcloudSmsService(config);
        }

        return null;
    }
}
