/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.common.validator.group;

/**
 * 默认 Group
 *
 * @author wangjiajian bladedance@vip.qq.coom
 * @since 1.0.0
 */
public interface DefaultGroup {

}
