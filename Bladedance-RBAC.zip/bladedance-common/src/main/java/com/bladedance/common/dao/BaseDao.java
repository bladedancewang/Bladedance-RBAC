/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.common.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 基础Dao
 *
 * @author wangjiajian bladedance@vip.qq.coom
 * @since 1.0.0
 */
public interface BaseDao<T> extends BaseMapper<T> {

}
