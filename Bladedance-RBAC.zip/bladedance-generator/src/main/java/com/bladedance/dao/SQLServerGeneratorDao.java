/**
 * Copyright (c) 2018 剑刃舞者开源 All rights reserved.
 * <p>
 * <p>
 * <p>
 * 版权所有，侵权必究！
 */

package com.bladedance.dao;

import org.apache.ibatis.annotations.Mapper;

/**
 * SQLServer代码生成器
 *
 * @author wangjiajian bladedance@vip.qq.coom
 */
@Mapper
public interface SQLServerGeneratorDao extends GeneratorDao {

}
